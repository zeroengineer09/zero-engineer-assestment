PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS administrators (id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, must_change_password INTEGER NOT NULL DEFAULT 0 CHECK(must_change_password IN(0,1)), created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS assessments (id INTEGER PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', academic_year TEXT NOT NULL DEFAULT 'ALL' CHECK(academic_year IN('FY','SY','TY','ALL')), duration_minutes INTEGER NOT NULL DEFAULT 30 CHECK(duration_minutes>0), passing_percentage REAL NOT NULL DEFAULT 60 CHECK(passing_percentage BETWEEN 0 AND 100), max_attempts INTEGER NOT NULL DEFAULT 1 CHECK(max_attempts>0), enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN(0,1)), auto_submit_tab_switch INTEGER NOT NULL DEFAULT 1, auto_submit_fullscreen_exit INTEGER NOT NULL DEFAULT 1, maximum_warnings INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS questions (id INTEGER PRIMARY KEY, assessment_id INTEGER NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, question_text TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'General', correct_option_id INTEGER, position INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS options (id INTEGER PRIMARY KEY, question_id INTEGER NOT NULL REFERENCES questions(id) ON DELETE CASCADE, option_text TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS examination_attempts (id TEXT PRIMARY KEY, assessment_id INTEGER NOT NULL REFERENCES assessments(id), candidate_name TEXT NOT NULL, candidate_email TEXT NOT NULL DEFAULT '', candidate_class TEXT NOT NULL DEFAULT '', candidate_division TEXT NOT NULL DEFAULT '', started_at TEXT NOT NULL, deadline_at TEXT NOT NULL, submitted_at TEXT, status TEXT NOT NULL DEFAULT 'in_progress' CHECK(status IN('in_progress','submitted','expired')), warnings INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE INDEX IF NOT EXISTS idx_attempt_email_assessment ON examination_attempts(candidate_email, assessment_id);
CREATE INDEX IF NOT EXISTS idx_attempt_status ON examination_attempts(status);
CREATE TABLE IF NOT EXISTS submitted_answers (id INTEGER PRIMARY KEY, attempt_id TEXT NOT NULL REFERENCES examination_attempts(id) ON DELETE CASCADE, question_id INTEGER NOT NULL REFERENCES questions(id), option_id INTEGER REFERENCES options(id), updated_at TEXT NOT NULL DEFAULT (datetime('now')), UNIQUE(attempt_id, question_id));
CREATE TABLE IF NOT EXISTS results (id INTEGER PRIMARY KEY, attempt_id TEXT NOT NULL UNIQUE REFERENCES examination_attempts(id), total_questions INTEGER NOT NULL, correct_answers INTEGER NOT NULL, incorrect_answers INTEGER NOT NULL, unanswered INTEGER NOT NULL, score INTEGER NOT NULL, percentage REAL NOT NULL, passed INTEGER NOT NULL CHECK(passed IN(0,1)), completed_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS violation_logs (id INTEGER PRIMARY KEY, attempt_id TEXT NOT NULL REFERENCES examination_attempts(id) ON DELETE CASCADE, violation_type TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT (datetime('now')));

CREATE TABLE IF NOT EXISTS teachers (id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, must_change_password INTEGER NOT NULL DEFAULT 1 CHECK(must_change_password IN(0,1)), active INTEGER NOT NULL DEFAULT 1 CHECK(active IN(0,1)), created_at TEXT NOT NULL DEFAULT (datetime('now')), password_changed_at TEXT);

CREATE TABLE IF NOT EXISTS student_accounts (
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  full_name TEXT NOT NULL,
  academic_year TEXT NOT NULL DEFAULT '',
  division TEXT NOT NULL DEFAULT '',
  roll_number TEXT NOT NULL DEFAULT '',
  admission_year TEXT NOT NULL DEFAULT '',
  practical_batch TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  must_change_password INTEGER NOT NULL DEFAULT 1 CHECK(must_change_password IN(0,1)),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN(0,1)),
  profile_photo_data TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  password_changed_at TEXT
);
